import { createHash, randomBytes } from "node:crypto";
import type { AuthResponse, AuthUser } from "@remotedesk/protocol";
import { query } from "./db.js";
import { hashPassword, verifyPassword } from "./password.js";
import { signUserToken } from "./jwt.js";
import { HttpError, requireUser, type Ctx } from "./http.js";
import { rateLimit } from "./ratelimit.js";
import { resolvePlan } from "./plans.js";
import { sendPasswordResetEmail } from "./email.js";

export const buildUser = async (id: string, email: string): Promise<AuthUser> => {
  const p = await resolvePlan(id);
  return { id, email, plan: p.plan, planRenewsAt: p.planRenewsAt, orgId: p.orgId, orgRole: p.orgRole };
};

const sha256 = (value: string): string => createHash("sha256").update(value).digest("hex");

const throttle = (ctx: Ctx, action: string, limit: number, windowMs: number): void => {
  if (!rateLimit(`${action}:${ctx.ip}`, limit, windowMs)) {
    throw new HttpError(429, "Çok fazla deneme. Birkaç dakika sonra tekrar deneyin.");
  }
};

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

interface UserRow {
  id: string;
  email: string;
  password_hash: string;
}

const readCredentials = (body: unknown): { email: string; password: string } => {
  const { email, password } = (body ?? {}) as { email?: unknown; password?: unknown };
  if (typeof email !== "string" || !EMAIL_RE.test(email.trim())) throw new HttpError(400, "Geçerli bir e-posta girin.");
  if (typeof password !== "string" || password.length < 8) throw new HttpError(400, "Şifre en az 8 karakter olmalı.");
  return { email: email.trim().toLowerCase(), password };
};

export const registerHandler = async (ctx: Ctx): Promise<AuthResponse> => {
  throttle(ctx, "register", 5, 60 * 60 * 1000);
  const { email, password } = readCredentials(ctx.body);
  const existing = await query<UserRow>("select id from users where email = $1", [email]);
  if (existing.rowCount) throw new HttpError(409, "Bu e-posta zaten kayıtlı.");

  const passwordHash = await hashPassword(password);
  const inserted = await query<UserRow>(
    "insert into users (email, password_hash) values ($1, $2) returning id, email",
    [email, passwordHash]
  );
  const user = inserted.rows[0];
  return { token: signUserToken(user), user: await buildUser(user.id, user.email) };
};

export const loginHandler = async (ctx: Ctx): Promise<AuthResponse> => {
  throttle(ctx, "login", 10, 15 * 60 * 1000);
  const { email, password } = readCredentials(ctx.body);
  const found = await query<UserRow>("select id, email, password_hash from users where email = $1", [email]);
  const user = found.rows[0];
  const ok = user ? await verifyPassword(password, user.password_hash) : false;
  if (!user || !ok) throw new HttpError(401, "E-posta veya şifre hatalı.");
  return { token: signUserToken(user), user: await buildUser(user.id, user.email) };
};

export const meHandler = async (ctx: Ctx) => {
  const { userId, email } = requireUser(ctx);
  return { user: await buildUser(userId, email) };
};

/**
 * Starts a password reset. Always returns { ok: true } so callers cannot probe which
 * emails exist. TODO(email): deliver the link by email instead of logging it.
 */
export const forgotHandler = async (ctx: Ctx): Promise<{ ok: true }> => {
  throttle(ctx, "forgot", 5, 60 * 60 * 1000);
  const { email } = (ctx.body ?? {}) as { email?: unknown };
  if (typeof email !== "string" || !EMAIL_RE.test(email.trim())) return { ok: true };

  const user = (await query<{ id: string }>("select id from users where email = $1", [email.trim().toLowerCase()]))
    .rows[0];
  if (user) {
    const token = randomBytes(32).toString("hex");
    await query("delete from password_resets where user_id = $1", [user.id]);
    await query(
      "insert into password_resets (token_hash, user_id, expires_at) values ($1, $2, now() + interval '1 hour')",
      [sha256(token), user.id]
    );
    const target = email.trim().toLowerCase();
    const sent = await sendPasswordResetEmail(target, token);
    if (!sent) console.log(`[password-reset] ${target} -> token ${token}`);
  }
  return { ok: true };
};

export const resetHandler = async (ctx: Ctx): Promise<AuthResponse> => {
  throttle(ctx, "reset", 10, 60 * 60 * 1000);
  const { token, password } = (ctx.body ?? {}) as { token?: unknown; password?: unknown };
  if (typeof token !== "string" || !token) throw new HttpError(400, "Geçersiz bağlantı.");
  if (typeof password !== "string" || password.length < 8) throw new HttpError(400, "Şifre en az 8 karakter olmalı.");

  const row = (
    await query<{ user_id: string; expires_at: Date }>(
      "select user_id, expires_at from password_resets where token_hash = $1",
      [sha256(token)]
    )
  ).rows[0];
  if (!row || row.expires_at.getTime() < Date.now()) throw new HttpError(400, "Bağlantının süresi dolmuş.");

  const passwordHash = await hashPassword(password);
  await query("update users set password_hash = $1 where id = $2", [passwordHash, row.user_id]);
  await query("delete from password_resets where user_id = $1", [row.user_id]);

  const user = (await query<UserRow>("select id, email from users where id = $1", [row.user_id])).rows[0];
  return { token: signUserToken(user), user: await buildUser(user.id, user.email) };
};
