const required = (name: string, fallback?: string): string => {
  const value = process.env[name]?.trim() || fallback;
  if (!value) throw new Error(`Missing required environment variable: ${name}`);
  return value;
};

export const env = {
  port: Number(process.env.PORT ?? 8787),
  /** Postgres connection string, e.g. postgresql://user:pass@host:5432/db or a Cloud SQL unix socket URL. */
  databaseUrl: process.env.DATABASE_URL?.trim() ?? "",
  jwtSecret: required("JWT_SECRET", process.env.NODE_ENV === "production" ? undefined : "dev-insecure-secret"),
  userTokenTtlSeconds: Number(process.env.USER_TOKEN_TTL ?? 60 * 60 * 24 * 7),
  deviceTokenTtlSeconds: Number(process.env.DEVICE_TOKEN_TTL ?? 60 * 60 * 24 * 180),
  turnUrl: process.env.TURN_URL?.trim() ?? "",
  turnSharedSecret: process.env.TURN_SHARED_SECRET?.trim() ?? "",
  corsOrigin: process.env.CORS_ORIGIN?.trim() ?? "*",
  publicUrl: (process.env.PUBLIC_URL?.trim() ?? "").replace(/\/$/, ""),
  resend: {
    apiKey: process.env.RESEND_API_KEY?.trim() ?? "",
    from: process.env.EMAIL_FROM?.trim() || "RemoteDesk <onboarding@resend.dev>"
  },
  stripe: {
    secretKey: process.env.STRIPE_SECRET_KEY?.trim() ?? "",
    webhookSecret: process.env.STRIPE_WEBHOOK_SECRET?.trim() ?? "",
    pricePro: process.env.STRIPE_PRICE_PRO?.trim() ?? "",
    priceTeam: process.env.STRIPE_PRICE_TEAM?.trim() ?? ""
  }
};

export const billingEnabled = (): boolean => Boolean(env.stripe.secretKey && env.stripe.pricePro);
