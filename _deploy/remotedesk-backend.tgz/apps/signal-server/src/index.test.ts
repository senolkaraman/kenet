import { randomUUID } from "node:crypto";
import { beforeAll, describe, expect, it } from "vitest";
import { DataType, newDb } from "pg-mem";

process.env.JWT_SECRET = "test-secret";

const { setPool, migrate } = await import("./db.js");
const mem = newDb();
mem.public.registerFunction({
  name: "gen_random_uuid",
  returns: DataType.uuid,
  impure: true,
  implementation: () => randomUUID()
});
const pg = mem.adapters.createPg();
setPool(new pg.Pool());

const { registerHandler, loginHandler, forgotHandler, resetHandler } = await import("./auth.js");
const { registerDeviceHandler, listDevicesHandler, patchDeviceHandler, deleteDeviceHandler, unattendedTicketHandler } =
  await import("./devices.js");
const { logEventHandler, listActivityHandler } = await import("./activity.js");
const { inviteHandler, pendingInvitesHandler, acceptInviteHandler, listMembersHandler, sharesOrg } = await import(
  "./orgs.js"
);
const { verifyToken } = await import("./jwt.js");
const { query } = await import("./db.js");

const grantPro = (userId: string) =>
  query("update users set plan = 'pro', subscription_status = 'active', plan_renews_at = now() + interval '1 month' where id = $1", [userId]);

let ipCounter = 0;
const ctx = (body: unknown, token?: string) => ({
  req: {} as never,
  res: {} as never,
  url: new URL("http://x/"),
  params: {} as Record<string, string>,
  body,
  claims: token ? verifyToken(token) : null,
  ip: `test-${ipCounter++}` // unique per call so the rate limiter never trips in tests
});

beforeAll(async () => {
  await migrate();
});

describe("account + device lifecycle", () => {
  let token = "";
  let deviceId = "";

  it("registers a user", async () => {
    const res = await registerHandler(ctx({ email: "a@b.com", password: "supersecret" }));
    expect(res.user.email).toBe("a@b.com");
    expect(res.user.plan).toBe("free");
    expect(res.token.split(".")).toHaveLength(3);
    token = res.token;
    await grantPro(res.user.id);
  });

  it("rejects duplicate email", async () => {
    await expect(registerHandler(ctx({ email: "a@b.com", password: "supersecret" }))).rejects.toThrow();
  });

  it("logs in with correct password", async () => {
    const res = await loginHandler(ctx({ email: "a@b.com", password: "supersecret" }));
    expect(res.user.id).toBeTruthy();
  });

  it("rejects wrong password", async () => {
    await expect(loginHandler(ctx({ email: "a@b.com", password: "wrongpass1" }))).rejects.toThrow();
  });

  it("registers a device and issues a device token", async () => {
    const res = await registerDeviceHandler(ctx({ name: "Ofis-PC" }, token));
    expect(res.device.id).toMatch(/^[A-Z0-9]{6}$/);
    expect(res.device.name).toBe("Ofis-PC");
    const claims = verifyToken(res.deviceToken);
    expect(claims?.typ).toBe("device");
    deviceId = res.device.id;
  });

  it("lists the user's devices", async () => {
    const res = await listDevicesHandler(ctx({}, token));
    expect(res.devices.map((d) => d.id)).toContain(deviceId);
  });

  it("renames a device", async () => {
    const c = ctx({ name: "Salon-PC" }, token);
    c.params.id = deviceId;
    const res = await patchDeviceHandler(c);
    expect(res.name).toBe("Salon-PC");
  });

  it("sets an unattended password", async () => {
    const c = ctx({ unattendedPassword: "let-me-in" }, token);
    c.params.id = deviceId;
    const res = await patchDeviceHandler(c);
    expect(res.unattendedEnabled).toBe(true);
  });

  it("issues an unattended ticket for the correct password and rejects a wrong one", async () => {
    const good = ctx({ password: "let-me-in" }, token);
    good.params.id = deviceId;
    const res = await unattendedTicketHandler(good);
    const claims = verifyToken(res.ticket);
    expect(claims?.typ).toBe("unattended");
    expect(claims?.sub).toBe(deviceId);

    const bad = ctx({ password: "wrong-pass" }, token);
    bad.params.id = deviceId;
    await expect(unattendedTicketHandler(bad)).rejects.toThrow();
  });

  it("blocks device access from another account", async () => {
    const other = await registerHandler(ctx({ email: "c@d.com", password: "supersecret" }));
    const c = ctx({ name: "hijack" }, other.token);
    c.params.id = deviceId;
    await expect(deleteDeviceHandler(c)).rejects.toThrow();
  });

  it("enforces the free-plan device limit and blocks unattended", async () => {
    const free = await registerHandler(ctx({ email: "free@b.com", password: "supersecret" }));
    const ids: string[] = [];
    for (let i = 0; i < 3; i += 1) ids.push((await registerDeviceHandler(ctx({ name: `d${i}` }, free.token))).device.id);
    await expect(registerDeviceHandler(ctx({ name: "d4" }, free.token))).rejects.toThrow(/Pro/);

    const c = ctx({ unattendedPassword: "nope-free" }, free.token);
    c.params.id = ids[0];
    await expect(patchDeviceHandler(c)).rejects.toThrow(/Pro/);
  });

  it("records and lists connection activity", async () => {
    const account = await registerHandler(ctx({ email: "act@b.com", password: "supersecret" }));
    const dev = await registerDeviceHandler(ctx({ name: "actor" }, account.token));
    await logEventHandler(ctx({ kind: "session-start", targetDeviceId: "TARGET" }, dev.deviceToken));
    await logEventHandler(ctx({ kind: "session-end" }, dev.deviceToken));
    await expect(logEventHandler(ctx({ kind: "bogus" }, dev.deviceToken))).rejects.toThrow();

    const list = await listActivityHandler(ctx({}, account.token));
    expect(list.events).toHaveLength(2);
    expect(list.events[0].kind).toBe("session-end"); // newest first (id desc)
    expect(list.events[1].targetDeviceId).toBe("TARGET");
  });

  it("rejects activity writes without a device token", async () => {
    const account = await registerHandler(ctx({ email: "act2@b.com", password: "supersecret" }));
    await expect(logEventHandler(ctx({ kind: "session-start" }, account.token))).rejects.toThrow();
  });
});

describe("password reset", () => {
  it("resets the password via a logged token", async () => {
    await registerHandler(ctx({ email: "reset@b.com", password: "originalpass" }));

    const logs: string[] = [];
    const original = console.log;
    console.log = (...args: unknown[]) => logs.push(args.join(" "));
    await forgotHandler(ctx({ email: "reset@b.com" }));
    await forgotHandler(ctx({ email: "nobody@nowhere.com" })); // no leak, no throw
    console.log = original;

    const line = logs.find((l) => l.includes("[password-reset] reset@b.com"));
    expect(line).toBeTruthy();
    const token = line!.split("token ")[1].trim();

    const res = await resetHandler(ctx({ token, password: "brand-new-pass" }));
    expect(res.user.email).toBe("reset@b.com");

    await expect(loginHandler(ctx({ email: "reset@b.com", password: "originalpass" }))).rejects.toThrow();
    const ok = await loginHandler(ctx({ email: "reset@b.com", password: "brand-new-pass" }));
    expect(ok.token.split(".")).toHaveLength(3);

    await expect(resetHandler(ctx({ token, password: "reuse-attempt" }))).rejects.toThrow(); // one-shot
  });
});

describe("teams / organisations", () => {
  it("invites a member, lets them accept, and grants shared access", async () => {
    const owner = await registerHandler(ctx({ email: "boss@team.com", password: "supersecret" }));
    const mate = await registerHandler(ctx({ email: "mate@team.com", password: "supersecret" }));

    const org = (
      await query<{ id: string }>(
        "insert into organizations (name, owner_user_id, seats, subscription_status) values ($1, $2, 5, 'active') returning id",
        ["Acme", owner.user.id]
      )
    ).rows[0];
    await query("insert into org_members (org_id, user_id, role) values ($1, $2, 'owner')", [org.id, owner.user.id]);

    const logs: string[] = [];
    const orig = console.log;
    console.log = (...a: unknown[]) => logs.push(a.join(" "));
    const inv = ctx({ email: "mate@team.com", role: "member" }, owner.token);
    inv.params.id = org.id;
    await inviteHandler(inv);
    console.log = orig;

    const pending = await pendingInvitesHandler(ctx({}, mate.token));
    expect(pending.invites).toHaveLength(1);

    const accept = ctx({}, mate.token);
    accept.params.id = pending.invites[0].id;
    await acceptInviteHandler(accept);

    const membersCtx = ctx({}, owner.token);
    membersCtx.params.id = org.id;
    const members = await listMembersHandler(membersCtx);
    expect(members.members.map((m) => m.email).sort()).toEqual(["boss@team.com", "mate@team.com"]);

    expect(await sharesOrg(owner.user.id, mate.user.id)).toBe(true);

    const mateMe = await import("./auth.js").then((m) => m.buildUser(mate.user.id, "mate@team.com"));
    expect(mateMe.plan).toBe("team");
  });

  it("stops invites once seats are full", async () => {
    const owner = await registerHandler(ctx({ email: "small@team.com", password: "supersecret" }));
    const org = (
      await query<{ id: string }>(
        "insert into organizations (name, owner_user_id, seats) values ($1, $2, 1) returning id",
        ["Solo", owner.user.id]
      )
    ).rows[0];
    await query("insert into org_members (org_id, user_id, role) values ($1, $2, 'owner')", [org.id, owner.user.id]);
    const inv = ctx({ email: "x@team.com" }, owner.token);
    inv.params.id = org.id;
    await expect(inviteHandler(inv)).rejects.toThrow(/oltuk/);
  });
});

describe("rate limiting", () => {
  it("blocks repeated logins from one ip", async () => {
    const { rateLimit } = await import("./ratelimit.js");
    let allowed = 0;
    for (let i = 0; i < 15; i += 1) if (rateLimit("login:1.2.3.4", 10, 60_000)) allowed += 1;
    expect(allowed).toBe(10);
  });
});
