import type { WebSocket } from "ws";

/** In-memory connection registry. Single Cloud Run instance for now (min=max=1). */
interface Conn {
  socket: WebSocket;
  sessionId: string;
  role: "device" | "controller";
  userId: string;
  deviceId?: string;
}

const bySession = new Map<string, Conn>();
const deviceToSession = new Map<string, string>();

export const addConn = (conn: Conn): void => {
  bySession.set(conn.sessionId, conn);
  if (conn.deviceId) deviceToSession.set(conn.deviceId, conn.sessionId);
};

export const removeConn = (sessionId: string): void => {
  const conn = bySession.get(sessionId);
  if (!conn) return;
  bySession.delete(sessionId);
  if (conn.deviceId && deviceToSession.get(conn.deviceId) === sessionId) {
    deviceToSession.delete(conn.deviceId);
  }
};

export const isDeviceOnline = (deviceId: string): boolean => deviceToSession.has(deviceId);

/** Resolve a routing target given either a live sessionId or an online deviceId. */
export const resolve = (target: string): Conn | undefined => {
  const direct = bySession.get(target);
  if (direct) return direct;
  const sessionId = deviceToSession.get(target);
  return sessionId ? bySession.get(sessionId) : undefined;
};

export const getConn = (sessionId: string): Conn | undefined => bySession.get(sessionId);
