import { randomUUID } from "node:crypto";
import type { WebSocket } from "ws";
import type { ClientMessage, ServerMessage } from "@remotedesk/protocol";
import { verifyToken } from "./jwt.js";
import { query } from "./db.js";
import { addConn, getConn, removeConn, resolve } from "./presence.js";
import { sharesOrg } from "./orgs.js";

const send = (socket: WebSocket, message: ServerMessage): void => {
  if (socket.readyState === socket.OPEN) socket.send(JSON.stringify(message));
};

export const handleConnection = (socket: WebSocket): void => {
  let sessionId: string | undefined;
  let ownerId: string | undefined;
  let role: "device" | "controller" | undefined;

  const authTimer = setTimeout(() => {
    if (!sessionId) {
      send(socket, { type: "error", code: "UNAUTHORIZED", message: "Authenticate within 10s." });
      socket.close(1008, "Unauthorized");
    }
  }, 10_000);

  socket.on("message", async (raw) => {
    let message: ClientMessage;
    try {
      message = JSON.parse(raw.toString()) as ClientMessage;
    } catch {
      send(socket, { type: "error", code: "INVALID_MESSAGE", message: "Message must be valid JSON." });
      return;
    }

    if (message.type === "hello") {
      const claims = verifyToken(message.token);
      if (!claims) {
        send(socket, { type: "error", code: "UNAUTHORIZED", message: "Invalid token." });
        socket.close(1008, "Unauthorized");
        return;
      }
      clearTimeout(authTimer);
      sessionId = randomUUID();
      if (claims.typ === "device") {
        role = "device";
        ownerId = claims.uid;
        addConn({ socket, sessionId, role, userId: claims.uid, deviceId: claims.sub });
        void query("update devices set last_seen_at = now(), name = coalesce($2, name) where id = $1", [
          claims.sub,
          typeof message.name === "string" && message.name.trim() ? message.name.trim().slice(0, 60) : null
        ]);
        send(socket, { type: "ready", role, sessionId, deviceId: claims.sub });
      } else {
        role = "controller";
        ownerId = claims.sub;
        addConn({ socket, sessionId, role, userId: claims.sub });
        send(socket, { type: "ready", role, sessionId });
      }
      return;
    }

    if (!sessionId || !ownerId || !role) {
      send(socket, { type: "error", code: "UNAUTHORIZED", message: "Send hello first." });
      return;
    }

    if (message.type === "signal") {
      const target = resolve(message.to);
      if (!target) {
        send(socket, { type: "peer-offline", to: message.to });
        return;
      }
      // Authorization: same account, or both parties in the same organisation.
      if (target.userId !== ownerId && !(await sharesOrg(ownerId, target.userId))) {
        send(socket, { type: "error", code: "FORBIDDEN", message: "Not your device." });
        return;
      }
      const self = getConn(sessionId);

      let payload = message.payload;
      if (payload.type === "connection-request" && payload.unattended) {
        const ticket = verifyToken(payload.unattended);
        const verified =
          ticket?.typ === "unattended" &&
          ticket.sub === target.deviceId &&
          (ticket.by === ownerId || (await sharesOrg(ticket.by, target.userId)));
        payload = { ...payload, unattended: verified ? "verified" : undefined };
      }

      send(target.socket, {
        type: "signal",
        from: sessionId,
        fromDevice: self?.deviceId,
        payload
      });
      return;
    }

    send(socket, { type: "error", code: "INVALID_MESSAGE", message: "Unknown message type." });
  });

  socket.on("close", () => {
    clearTimeout(authTimer);
    if (sessionId) removeConn(sessionId);
  });
};
